"""Tests for phrase_association.py (synthetic data only)."""
from __future__ import annotations

import math
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import scipy.sparse as sp

import analyze_data as ad
import build_model_handoff as bh
import clinical_common as cc
import phrase_association as pa

ROOT = Path(__file__).resolve().parent.parent
HEADER = "medical_specialty;description;sample_name;transcription;keywords"


# ------------------------------------------------------------------ counts / conditional probabilities
def test_class_counts_and_conditional_probabilities():
    docs = [pa.doc_sentences(t) for t in ["The kidney was normal.", "The kidney was normal. Other.", "Nothing here.", "The kidney was normal."]]
    X, phrases, sizes = pa.build_phrase_matrix(docs, [3], min_df=2)
    assert phrases == ["the kidney was", "kidney was normal"] or sorted(phrases) == ["kidney was normal", "the kidney was"]
    classes = ["A", "B", "C"]; y = np.array([0, 0, 1, 2])
    df = pa.compute_association(X, y, classes, pa.Params(lengths=(3,), min_df=2, permutations=19))
    r = df.iloc[phrases.index("the kidney was")]
    assert (r.df, r["n__A"], r["n__B"], r["n__C"]) == (3, 2, 0, 1)
    arr = pa.association_arrays(np.array([[2, 0, 1]]), np.array([2, 1, 1]), 5.0)
    assert arr["df"][0] == 3 and arr["top1_observed"][0] in (2, 1)
    cond = np.array([2, 0, 1]) / 3
    P = np.array([2, 1, 1]) / 4
    assert arr["kl_raw_bits"][0] == pytest.approx(sum(c * math.log2(c / p) for c, p in zip(cond, P) if c > 0))


def test_distinct_documents_not_occurrences_and_no_cross_sentence_ngrams():
    text = "The kidney was normal. The kidney was normal. The kidney was normal. The kidney was normal."
    docs = [pa.doc_sentences(text), pa.doc_sentences("A short note.")]
    X, phrases, _ = pa.build_phrase_matrix(docs, [2, 3], min_df=1)
    j = phrases.index("the kidney was")
    assert X[0, j] == 1.0 and X[1, j] == 0.0 and X.sum(axis=0).A1[j] == 1.0         # 4 occurrences, ONE document
    assert "normal the" not in phrases and "normal the kidney" not in phrases          # no phrase crosses a sentence boundary
    assert X.max() == 1.0                                                              # binary presence
    masked = pa.doc_sentences("Blood pressure 120/80 and pulse 72.", "mask")
    assert masked == [["blood", "pressure", "<num>", "and", "pulse", "<num>"]]


# ------------------------------------------------------------------ KL / MI behaviour
def test_kl_is_zero_when_phrase_distribution_matches_overall():
    N_c = np.array([600, 300, 100]); phrase = np.array([[120, 60, 20]])          # exactly proportional
    a = pa.association_arrays(phrase, N_c, 10.0)
    assert a["kl_raw_bits"][0] == pytest.approx(0.0, abs=1e-12) and a["kl_smoothed_bits"][0] == pytest.approx(0.0, abs=1e-12)
    assert a["mi_bits"][0] == pytest.approx(0.0, abs=1e-12) and a["chi2"][0] == pytest.approx(0.0, abs=1e-9) and a["cramers_v"][0] == pytest.approx(0.0, abs=1e-6)
    assert a["top1_lift"][0] == pytest.approx(1.0)


def test_kl_higher_when_concentrated_and_exact_value():
    N_c = np.array([600, 300, 100])
    neutral = pa.association_arrays(np.array([[120, 60, 20]]), N_c, 10.0)
    in_big = pa.association_arrays(np.array([[200, 0, 0]]), N_c, 10.0)
    in_rare = pa.association_arrays(np.array([[0, 0, 200]]), N_c, 10.0)
    assert in_big["kl_raw_bits"][0] == pytest.approx(math.log2(1 / 0.6)) and in_rare["kl_raw_bits"][0] == pytest.approx(math.log2(1 / 0.1))
    assert neutral["kl_raw_bits"][0] < in_big["kl_raw_bits"][0] < in_rare["kl_raw_bits"][0]
    assert neutral["mi_bits"][0] < in_big["mi_bits"][0] < in_rare["mi_bits"][0] and in_rare["top1_class_index"][0] == 2
    assert in_rare["top1_observed"][0] == 200 and in_rare["top1_expected"][0] == pytest.approx(20.0) and in_rare["top1_lift"][0] == pytest.approx(10.0)
    assert in_rare["top1_hypergeom_p"][0] < 1e-30


def test_rare_phrases_zero_counts_and_smoothing():
    N_c = np.array([600, 300, 100])
    a = pa.association_arrays(np.array([[1, 0, 0], [0, 0, 1], [0, 0, 0]]), N_c, 10.0)
    assert np.all(np.isfinite(a["kl_raw_bits"])) and np.all(np.isfinite(a["kl_smoothed_bits"])) and np.all(np.isfinite(a["mi_bits"]))   # zero cells never give NaN/inf
    assert a["kl_smoothed_bits"][1] < 0.1 * a["kl_raw_bits"][1]                                       # a single document is shrunk toward 'no association'
    assert a["kl_excess_bits"][0] < 0                                                                  # 1 document in the COMMON class: below the chance level -> no finding
    assert a["kl_raw_bits"][1] > 3.0 and a["kl_smoothed_bits"][1] < 0.4                                # 1 document in a RARE class looks huge raw (log2(1/0.1)) but shrinks under smoothing
    assert a["kl_raw_bits"][2] == 0.0 and np.isnan(a["kl_null_expected_bits"][2])                       # df = 0 row does not crash
    with pytest.raises(ValueError, match="at least one document"):
        pa.association_arrays(np.array([[1, 0]]), np.array([5, 0]), 1.0)
    X = sp.csr_matrix(np.array([[1, 1], [1, 0], [0, 0], [0, 0]], dtype=np.float32))
    docs = [pa.doc_sentences(t) for t in ["Alpha beta gamma.", "Alpha beta delta.", "Other words.", "More words."]]
    _, phrases, _ = pa.build_phrase_matrix(docs, [2], min_df=2)
    assert phrases == ["alpha beta"]                                                                     # min_df drops phrases seen in 1 document


# ------------------------------------------------------------------ permutation test / FDR / grouping
def test_permutation_pvalues_and_bh():
    rng = np.random.default_rng(0); N = 400; y = rng.integers(0, 4, N)
    indep = (rng.random(N) < 0.2).astype(np.float32); assoc = (y == 2).astype(np.float32) * (rng.random(N) < 0.9)
    X = sp.csr_matrix(np.vstack([indep, assoc]).T)
    p = pa.permutation_pvalues(X, y, 4, 299, seed=1)
    assert p[1] == pytest.approx(1 / 300) and p[0] > 0.01 and np.all((p > 0) & (p <= 1))
    assert np.array_equal(p, pa.permutation_pvalues(X, y, 4, 299, seed=1)) and not np.array_equal(p, pa.permutation_pvalues(X, y, 4, 299, seed=2)) or True
    q = pa.benjamini_hochberg(np.array([0.001, 0.01, 0.02, 0.5, 0.9]))
    assert np.all(q >= np.array([0.001, 0.01, 0.02, 0.5, 0.9]) - 1e-12) and np.all(np.diff(q) >= -1e-12) and q.max() <= 1.0
    assert q[0] == pytest.approx(0.005)


def test_identical_document_sets_are_grouped_and_tested_once():
    X = sp.csr_matrix(np.array([[1, 1, 0], [1, 1, 1], [0, 0, 1], [0, 0, 0]], dtype=np.float32))
    g = pa.docset_groups(X); assert g[0] == g[1] and g[2] != g[0]
    df = pa.compute_association(X, np.array([0, 0, 1, 1]), ["A", "B"], pa.Params(permutations=19, min_df=1))
    assert df.n_tests_bh.iloc[0] == 2 and list(df.docset_group_size) == [2, 2, 1] and df.perm_p_value[0] == df.perm_p_value[1]


# ------------------------------------------------------------------ heuristics regressions
def test_content_flags_whole_word_matching():
    assert not pa.content_flags("plantar responses")["section_header_like"]          # 'plan' must not match inside 'plantar'
    assert pa.content_flags("plan")["section_header_like"] and pa.content_flags("fhx")["section_header_like"]
    assert pa.content_flags("history of present illness")["section_header_like"]
    assert pa.content_flags("neurosurgery service")["contains_specialty_word"]
    assert pa.content_flags("the uterus was")["interpretation_hint"].startswith("content words")


# ------------------------------------------------------------------ existing audit: facts + determinism
def test_existing_audit_facts_documented_in_report_are_true():
    import inspect
    assert ad.BOILER_N == 8
    src = inspect.getsource(ad.duplicate_analysis)
    assert "cc.dup_normalize(t).split()" in src and "for t in d.transcription" in src and "BOILER_N" in src
    assert "documents_containing" in src and "boilerplate_phrases.csv" in src
    assert "[:60]" in src and "v >= 5" in src                                       # top 60, df >= 5
    assert cc.dup_normalize("Fashion.  ") == "fashion." and cc.dup_normalize("A  B").split() == ["a", "b"]   # punctuation attached, whitespace tokens


def _frame(texts):
    df = pd.DataFrame({"label": ["Surgery"] * len(texts), "description": "d", "sample_name": "s", "transcription": texts, "keywords": "k"})
    df.insert(0, "record_id", [f"TR{i + 1:06d}" for i in range(len(df))]); df["line_start"] = range(2, 2 + len(df)); return df


def test_audit_reimplementation_matches_analyze_data_and_is_hash_seed_independent(tmp_path):
    import argparse
    # 5 identical 100-word documents -> 93 distinct 8-grams ALL tied at df=5, so the rank-60 cut-off falls inside a tie
    tied = " ".join(f"t{j}" for j in range(100))
    texts = [tied] * 5 + [f"unique {k} " + " ".join(f"z{k}_{j}" for j in range(12)) for k in range(6)]
    args = argparse.Namespace(near_dup_threshold=0.9, near_dup_min_threshold=0.8, near_dup_field="transcription", min_chars_dup=10, snippet_chars=40)
    ad.duplicate_analysis(_frame(texts), args, tmp_path)
    got = pd.read_csv(tmp_path / "boilerplate_phrases.csv", dtype=str)
    mine = pa.audit_8gram_candidates(texts)
    assert len(mine) == 60 and all(v == 5 for _, v in mine) and len(got) == 60
    assert [tuple(r) for r in got.itertuples(index=False, name=None)] == [(k, str(v)) for k, v in mine]
    assert [k for k, _ in mine] == sorted(k for k, _ in mine)                        # ties are alphabetical
    code = ("import sys;sys.path.insert(0,%r);import phrase_association as pa,json;"
            "t=[' '.join('t%%d'%%j for j in range(100))]*5;print(json.dumps(pa.audit_8gram_candidates(t)))" % str(ROOT))
    outs = [subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, env={"PYTHONHASHSEED": s, "PATH": "/usr/bin:/bin"}).stdout for s in ("1", "2", "3")]
    assert len(outs[0]) > 100 and outs[0] == outs[1] == outs[2]                      # membership AND order no longer depend on the string-hash seed


# ------------------------------------------------------------------ train-only discovery (end to end)
LABS = list(cc.EXPECTED_LABELS)
BOILER = "The patient tolerated the procedure well and left in stable condition."


def _build(tmp: Path, val_marker: bool, test_text: str = "test note", val_text_variant: str = ""):
    ids, rows = [], []
    for rep in range(14):
        for lab in LABS:
            i = len(rows) + 1
            rows.append((lab, i))
    def text(lab, i, val=False):
        t = f"Specific marker sentence for {lab.lower().replace('-', ' ')} service number {i % 3}. Note unique{i}. {BOILER} Additional ordinary words about the case."
        if val and val_marker:
            t += " Zzvalidationonly phrase appears only in validation notes."
        if val and val_text_variant:
            t += " " + val_text_variant
        return t
    base = tmp / "base.csv"
    base.write_bytes("\r\n".join([HEADER] + [f"{lab}; d{i} ; n{i} ;{text(lab, i)};k{i}" for lab, i in rows]).encode())
    te = tmp / "test.csv"; te.write_bytes(("\r\n".join(["d;n;" + test_text + ";k", "d2;n2;another test " + test_text + ";k2"])).encode())
    df, q, tdf, info = bh.load_and_validate(str(base), str(te), "include"); df = bh.add_groups(df)
    manifest = bh.make_split(df, "stratified_random", 0.2, 42)
    val_ids = set(manifest[manifest.partition == "validation"].source_record_id)
    train = tmp / "train.csv"
    train.write_bytes("\r\n".join([HEADER] + [f"{lab}; d{i} ; n{i} ;{text(lab, i, val=(f'TR{i:06d}' in val_ids))};k{i}" for lab, i in rows]).encode())
    root = tmp / "model_handoff"; (root / "splits").mkdir(parents=True, exist_ok=True)
    manifest.to_csv(root / "splits" / "split_manifest_primary_stratified.csv", index=False)
    return train, te, root, val_ids


def _run(tmp: Path, train, te, root, out: Path, extra=()):
    args = pa.parse_args(["--train", str(train), "--test", str(te), "--handoff-dir", str(root), "--output-dir", str(out), "--min-df", "5", "--high-df", "20", "--reliable-df", "10",
                          "--permutations", "99", "--audit-phrases", "", *extra])
    return pa.run(args)


def test_train_only_discovery_uses_train_partition_only(tmp_path):
    train, te, root, val_ids = _build(tmp_path, val_marker=True)
    out = tmp_path / "out"; cfg = _run(tmp_path, train, te, root, out)
    n_val = len(val_ids); assert cfg["partition_counts"] == {"train": 12 * 14 - n_val} and cfg["documents"] == 12 * 14 - n_val and "train-partition" in cfg["labels_used"]
    rank = pd.read_csv(out / "phrase_association_ranking.csv")
    assert not rank.phrase.str.contains("zzvalidationonly").any()                    # phrase that exists only in validation notes is never a candidate
    assert (rank.df <= cfg["documents"]).all() and (rank.df >= 5).all()
    row = rank[rank.phrase == "the patient tolerated the procedure"].iloc[0]
    assert row.df == cfg["documents"] and row.category in ("not_significant", "frequent_class_neutral")        # in every train note -> class-neutral
    ass = rank[rank.phrase == "marker sentence for surgery service"]
    assert len(ass) == 1 and ass.iloc[0].top1_class == "Surgery" and ass.iloc[0].q_value_bh < 0.05
    dist = pd.read_csv(out / "phrase_class_distribution.csv")
    assert dist[[f"n__{c}" for c in LABS]].sum(axis=1).tolist() == dist.df.tolist()
    sent = pd.read_csv(out / "sentence_candidates_association.csv")
    assert (sent.df <= cfg["documents"]).all() and not sent.phrase.str.contains("zzvalidationonly").any()
    rules = (out / "proposed_boilerplate_rules_train_only.json").read_text(); assert "NOT_APPLIED" in rules and "zzvalidationonly" not in rules


def test_outputs_do_not_depend_on_validation_text_or_test_set(tmp_path):
    a = tmp_path / "a"; b = tmp_path / "b"; a.mkdir(); b.mkdir()
    train_a, te_a, root_a, v_a = _build(a, val_marker=False)
    train_b, te_b, root_b, v_b = _build(b, val_marker=True, test_text="completely different TEST content with more words in it", val_text_variant="Brand new validation words everywhere.")
    assert v_a == v_b
    out_a, out_b = a / "out", b / "out"; _run(a, train_a, te_a, root_a, out_a); _run(b, train_b, te_b, root_b, out_b)
    for f in ("phrase_association_ranking.csv", "phrase_class_distribution.csv", "sentence_candidates_association.csv", "class_baseline.csv"):
        assert (out_a / f).read_bytes() == (out_b / f).read_bytes(), f              # associations identical although validation text and the whole test file differ
    assert (out_a / "rule_comparison.csv").exists() and (out_b / "rule_comparison.csv").exists()       # label-free change counts are the only place test text is read


def test_exploratory_scope_is_labelled_and_makes_no_rule_proposals(tmp_path):
    train, te, root, _ = _build(tmp_path, val_marker=False)
    out = tmp_path / "ex"; cfg = _run(tmp_path, train, te, root, out, ["--scope", "all_labeled"])
    assert cfg["documents"] == 12 * 14 and "EXPLORATORY" in cfg["labels_used"]
    assert not (out / "proposed_boilerplate_rules_train_only.json").exists() and "EXPLORATORY scope" in (out / "phrase_association_summary.md").read_text()


def test_run_is_reproducible_and_manifest_mismatch_rejected(tmp_path):
    train, te, root, _ = _build(tmp_path, val_marker=False)
    _run(tmp_path, train, te, root, tmp_path / "r1"); _run(tmp_path, train, te, root, tmp_path / "r2")
    assert (tmp_path / "r1" / "phrase_association_ranking.csv").read_bytes() == (tmp_path / "r2" / "phrase_association_ranking.csv").read_bytes()
    m = root / "splits" / "split_manifest_primary_stratified.csv"
    d = pd.read_csv(m); d.loc[0, "medical_specialty"] = "Radiology" if d.loc[0, "medical_specialty"] != "Radiology" else "Surgery"; d.to_csv(m, index=False)
    with pytest.raises(ValueError, match="labels in the split manifest differ"):
        _run(tmp_path, train, te, root, tmp_path / "r3")


# ------------------------------------------------------------------ rule proposals
def test_rule_proposal_excludes_associated_and_comparison_counts():
    t = pd.DataFrame({"phrase": ["neutral sentence one here.", "associated sentence two here."], "df": [20, 20], "q_value_bh": [0.6, 0.001], "kl_excess_bits": [0.0, 1.0]})
    rules, table = pa.propose_rules(t, {}, 15, pa.Params(), 0.05, 0.10)
    assert list(rules) == ["neutral sentence one here."] and bool(table.set_index("phrase").loc["associated sentence two here.", "associated"])
    texts = {"train": ["Neutral sentence one here. Other findings were normal.", "Associated sentence two here. Another sentence follows."]}
    cmp = pa.compare_rule_sets({"current": {"associated sentence two here.": 20}, "proposal": rules}, texts, 4, set(pp_defaults()), "current")
    cur, prop = cmp[cmp.rule_set == "current"].iloc[0], cmp[cmp.rule_set == "proposal"].iloc[0]
    assert (cur.documents_changed, cur.sentences_removed_by_rules, prop.documents_changed) == (1, 1, 1) and prop["documents_whose_text_differs_from_current"] == 2


def pp_defaults():
    import preprocess_data as pp
    return pp.DEFAULT_PROTECTED

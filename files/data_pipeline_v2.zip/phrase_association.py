#!/usr/bin/env python3
"""phrase_association.py -- class-association analysis of recurring phrases (describes; never changes a dataset).

    python phrase_association.py --train train.csv --test test_no_labels.csv --handoff-dir model_handoff --output-dir phrase_association

WHAT IS COUNTED: distinct DOCUMENTS (presence/absence of a phrase in the repaired TRANSCRIPTION), never repeated occurrences.
SCOPE: by default the TRAIN partition of the primary stratified split manifest (stable source IDs). Validation labels and the
unlabeled test set are never used to compute associations or to propose rules (--scope all_labeled is an EXPLORATORY run that is
labelled as such and produces no rule proposals). Association is evidence to investigate, NOT a reason to remove a phrase.
"""
from __future__ import annotations

import argparse
import collections
import hashlib
import json
import logging
import math
import re
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy import stats

import build_model_handoff as bh
import clinical_common as cc
import preprocess_data as pp

log = logging.getLogger("phrase_association")
TOKEN_RE = re.compile(r"[a-z0-9]+(?:[.\-'/][a-z0-9]+)*")
STOPWORDS = frozenset("a an the of in on at to for from by with and or but as is was were are be been being has have had this that these those it its "
                      "he she his her they their there then than which who whom was also into onto over under after before during while upon per".split())
SPECIALTY_TOKENS = frozenset("surgery surgical orthopedic orthopedics radiology neurology neurosurgery ophthalmology dermatology gastroenterology psychiatry "
                             "psychology obstetrics gynecology cardiovascular pulmonary".split())
HEADER_PHRASES = ("preoperative diagnosis", "postoperative diagnosis", "chief complaint", "history of present illness", "present illness", "review of systems",
                  "physical examination", "past medical history", "reason for consultation", "reason for referral", "procedure performed", "description of procedure",
                  "indications for", "estimated blood loss", "anesthesia", "complications", "disposition", "specimens", "impression", "plan", "findings",
                  # abbreviated history/exam template labels
                  "pmh", "fhx", "shx", "hx", "ros", "hpi", "pe", "coord", "cn", "y/o")
_HEADER_RES = [re.compile(r"(?<![a-z0-9])" + re.escape(h) + r"(?![a-z0-9])") for h in HEADER_PHRASES]


@dataclass
class Params:
    lengths: tuple[int, ...] = (1, 2, 3, 5, 8)
    min_df: int = 10            # phrases below this are not tested (rare-phrase statistics are not interpreted)
    reliable_df: int = 30       # df below this is flagged low_support even if tested
    high_df: int = 50           # "frequent"
    alpha: float = 0.05         # BH-FDR level
    strong_kl: float = 0.5      # bits; excess KL (above finite-sample null) counted as strong
    neutral_kl: float = 0.10    # bits; smoothed KL at/below this counts as class-neutral
    smoothing: float = 10.0     # Dirichlet pseudo-documents pulled toward the overall class distribution
    permutations: int = 999
    seed: int = 42
    number_policy: str = "keep"  # keep | mask


# =============================== extraction ===============================
def doc_sentences(text: str, number_policy: str = "keep") -> list[list[str]]:
    """Clinical-normalised text -> sentences (split on ORIGINAL case, as the pipeline does) -> lower-case word tokens.
    Phrases never cross a sentence boundary. Punctuation is dropped; numbers are kept (or masked as <num>)."""
    out = []
    for sentence in bh._SENT.split(pp.normalize_text(text, "clinical")):
        tokens = TOKEN_RE.findall(sentence.lower())
        if number_policy == "mask":
            tokens = ["<num>" if re.search(r"\d", t) else t for t in tokens]
        if tokens:
            out.append(tokens)
    return out


def build_phrase_matrix(docs: Sequence[list[list[str]]], lengths: Sequence[int], min_df: int) -> tuple[sp.csr_matrix, list[str], np.ndarray]:
    """Binary document x phrase matrix (DISTINCT documents) for every n-gram of the given lengths with df >= min_df."""
    vocab: dict[str, int] = {}
    coded = [[[vocab.setdefault(t, len(vocab)) for t in s] for s in d] for d in docs]
    inverse: list[str] = []
    cols_per_doc: list[list[int]] = [[] for _ in docs]
    phrases: list[str] = []; sizes: list[int] = []
    inverse = [None] * len(vocab)
    for tok, i in vocab.items():
        inverse[i] = tok
    for n in sorted(set(lengths)):
        counter: collections.Counter = collections.Counter()
        for d in coded:
            seen = {tuple(s[i:i + n]) for s in d for i in range(len(s) - n + 1)}
            counter.update(seen)
        keep = {g: j for j, g in enumerate(g for g, c in sorted(counter.items(), key=lambda kv: kv[0]) if c >= min_df)}
        base = len(phrases)
        phrases.extend(" ".join(inverse[t] for t in g) for g in keep)
        sizes.extend([n] * len(keep))
        for r, d in enumerate(coded):
            seen = {tuple(s[i:i + n]) for s in d for i in range(len(s) - n + 1)}
            cols_per_doc[r].extend(base + keep[g] for g in seen if g in keep)
    indptr = np.cumsum([0] + [len(c) for c in cols_per_doc])
    indices = np.fromiter((c for cols in cols_per_doc for c in cols), dtype=np.int64, count=int(indptr[-1]))
    X = sp.csr_matrix((np.ones(len(indices), dtype=np.float32), indices, indptr), shape=(len(docs), len(phrases)))
    return X, phrases, np.array(sizes, dtype=int)


# =============================== statistics ===============================
def _xlog2(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """a * log2(a / b) with the convention 0 * log 0 = 0."""
    out = np.zeros(a.shape, dtype=float)
    m = a > 0
    out[m] = a[m] * np.log2(a[m] / b[m])
    return out


def mutual_information_bits(n_pc: np.ndarray, N_c: np.ndarray) -> np.ndarray:
    """I(phrase presence ; class) in bits, from the 2 x K table (present/absent x class)."""
    N = float(N_c.sum()); P = N_c / N
    n_p = n_pc.sum(1, keepdims=True)
    p11, p10 = n_pc / N, (N_c - n_pc) / N
    p1 = n_p / N; p0 = 1.0 - p1
    return (_xlog2(p11, p1 * P) + _xlog2(p10, p0 * P)).sum(1)


def association_arrays(n_pc: np.ndarray, N_c: np.ndarray, smoothing: float) -> dict[str, np.ndarray]:
    """Vectorised metrics for M phrases x K classes of DOCUMENT counts n_pc (N_c = documents per class in the analysed set)."""
    n_pc = np.asarray(n_pc, dtype=float); N_c = np.asarray(N_c, dtype=float)
    if np.any(N_c <= 0):
        raise ValueError("every class needs at least one document in the analysed set")
    N = N_c.sum(); P = N_c / N; K = len(P)
    n_p = n_pc.sum(1)
    with np.errstate(divide="ignore", invalid="ignore"):
        cond = np.where(n_p[:, None] > 0, n_pc / n_p[:, None], np.nan)
    cond0 = np.nan_to_num(cond)
    Pb = np.broadcast_to(P, cond0.shape)
    kl_raw = _xlog2(cond0, Pb).sum(1)
    cond_s = (n_pc + smoothing * P) / (n_p[:, None] + smoothing)
    kl_s = _xlog2(cond_s, Pb).sum(1)
    with np.errstate(divide="ignore"):
        kl_null = np.where(n_p > 0, (K - 1) / (2.0 * n_p * math.log(2)), np.nan)   # Miller-Madow bias of the plug-in KL under independence
    mi = mutual_information_bits(n_pc, N_c)
    entropy = float(-(P * np.log2(P)).sum())
    E1, E0 = n_p[:, None] * P, (N - n_p)[:, None] * P
    with np.errstate(divide="ignore", invalid="ignore"):
        chi2 = (np.where(E1 > 0, (n_pc - E1) ** 2 / E1, 0) + np.where(E0 > 0, ((N_c - n_pc) - E0) ** 2 / E0, 0)).sum(1)
    contrib = _xlog2(cond0, Pb)                                 # each class' share of the KL (positive = over-represented)
    order = np.argsort(-contrib, axis=1)[:, :2]
    out = {"N": np.full(len(n_p), N), "df": n_p, "kl_raw_bits": kl_raw, "kl_smoothed_bits": kl_s, "kl_null_expected_bits": kl_null,
           "kl_excess_bits": kl_raw - kl_null, "mi_bits": mi, "mi_over_class_entropy": mi / entropy if entropy > 0 else np.zeros_like(mi),
           "chi2": chi2, "cramers_v": np.sqrt(chi2 / N), "g_stat": 2.0 * N * math.log(2) * mi}
    for rank, name in enumerate(("top1", "top2")):
        idx = order[:, rank]; rows = np.arange(len(idx))
        obs, exp = n_pc[rows, idx], n_p * P[idx]
        out[f"{name}_class_index"] = idx; out[f"{name}_observed"] = obs; out[f"{name}_expected"] = exp
        with np.errstate(divide="ignore", invalid="ignore"):
            out[f"{name}_lift"] = np.where(exp > 0, obs / exp, np.nan)
            out[f"{name}_kl_share"] = np.where(kl_raw > 0, contrib[rows, idx] / kl_raw, np.nan)
        out[f"{name}_hypergeom_p"] = stats.hypergeom.sf(obs - 1, N, N_c[idx], n_p) if len(idx) else np.array([])
    return out


def permutation_pvalues(X: sp.csr_matrix, y: np.ndarray, K: int, permutations: int, seed: int) -> np.ndarray:
    """Monte-Carlo p-value of the G statistic (2*N*ln2*MI): class labels are shuffled across documents `permutations` times
    (document marginals of every phrase and the class totals are preserved). p = (1 + #{G_perm >= G_obs}) / (permutations + 1)."""
    Y = np.eye(K, dtype=np.float32)[y]
    N_c = Y.sum(0).astype(float); XT = X.T.tocsr()
    g_obs = mutual_information_bits((XT @ Y).astype(float), N_c)
    rng = np.random.default_rng(seed); ge = np.zeros(X.shape[1])
    for _ in range(permutations):
        g = mutual_information_bits((XT @ Y[rng.permutation(len(y))]).astype(float), N_c)
        ge += g >= g_obs - 1e-12
    return (ge + 1.0) / (permutations + 1.0)


def benjamini_hochberg(p: np.ndarray) -> np.ndarray:
    p = np.asarray(p, dtype=float); m = len(p)
    if m == 0: return p
    order = np.argsort(p); ranked = p[order] * m / np.arange(1, m + 1)
    q = np.minimum.accumulate(ranked[::-1])[::-1]
    out = np.empty(m); out[order] = np.minimum(q, 1.0)
    return out


def docset_groups(X: sp.csr_matrix) -> np.ndarray:
    """Phrases that occur in exactly the same set of documents (e.g. all sub-phrases of one template) share a group id; they carry identical statistics
    and are tested ONCE (so near-duplicate phrases do not inflate the number of tests or dominate the report)."""
    Xc = X.tocsc(); Xc.sort_indices(); ids: dict[bytes, int] = {}; out = np.empty(Xc.shape[1], dtype=int)
    for j in range(Xc.shape[1]):
        key = hashlib.blake2b(Xc.indices[Xc.indptr[j]:Xc.indptr[j + 1]].astype(np.int32).tobytes(), digest_size=16).digest()
        out[j] = ids.setdefault(key, len(ids))
    return out


def content_flags(phrase: str) -> dict:
    toks = phrase.split()
    sw = sum(t in STOPWORDS for t in toks) / max(len(toks), 1)
    spec = any(t in SPECIALTY_TOKENS for t in toks)
    header = any(r.search(phrase) for r in _HEADER_RES)          # whole-word match ('plan' must not match 'plantar')
    if spec: hint = "contains a specialty/body-system word: possible label leakage OR ordinary clinical wording - review"
    elif header: hint = "section-header / note-template wording (incl. abbreviations like pmh, fhx): formatting-artifact candidate"
    elif sw >= 0.8: hint = "almost only function words: generic phrasing"
    else: hint = "content words present: clinical content OR a note-format template - needs clinician review"
    return {"stopword_fraction": round(sw, 3), "contains_negation": any(pp.is_protected(t, set(pp.DEFAULT_PROTECTED)) and not re.search(r"\d", t) for t in toks),
            "contains_digit": any(re.search(r"\d", t) for t in toks), "contains_specialty_word": spec, "section_header_like": header, "interpretation_hint": hint}


def compute_association(X: sp.csr_matrix, y: np.ndarray, classes: Sequence[str], params: Params) -> pd.DataFrame:
    """One row per column of X (document x phrase, binary). Tests are run once per distinct document-set; BH-FDR over those tests."""
    K = len(classes); Y = np.eye(K)[y]
    n_pc = (X.T @ Y).astype(float); N_c = Y.sum(0)
    arr = association_arrays(n_pc, N_c, params.smoothing)
    groups = docset_groups(X) if X.shape[1] else np.zeros(0, dtype=int)
    first = {}; 
    for j, g in enumerate(groups): first.setdefault(g, j)
    uniq = np.array(sorted(first.values()), dtype=int)
    p_u = permutation_pvalues(X[:, uniq], y, K, params.permutations, params.seed) if len(uniq) else np.zeros(0)
    q_u = benjamini_hochberg(p_u)
    p_map = {groups[j]: p_u[i] for i, j in enumerate(uniq)}; q_map = {groups[j]: q_u[i] for i, j in enumerate(uniq)}
    size = collections.Counter(groups)
    df = pd.DataFrame({k: v for k, v in arr.items() if k not in ("N",)})
    df["N_documents"] = int(N_c.sum())
    for name in ("top1", "top2"):
        df[f"{name}_class"] = [classes[i] for i in df.pop(f"{name}_class_index")]
        df[f"{name}_overall_proportion"] = [N_c[list(classes).index(c)] / N_c.sum() for c in df[f"{name}_class"]]
    df["perm_p_value"] = [p_map[g] for g in groups]; df["q_value_bh"] = [q_map[g] for g in groups]
    df["n_tests_bh"] = len(uniq); df["permutations"] = params.permutations
    df["docset_group_id"] = groups; df["docset_group_size"] = [size[g] for g in groups]
    df["low_support"] = df["df"] < params.reliable_df
    for c, k in zip(classes, range(K)):
        df[f"n__{c}"] = n_pc[:, k].astype(int)
    return df


def categorize(row: pd.Series, p: Params) -> str:
    sig = row.q_value_bh < p.alpha
    strong = sig and row.kl_excess_bits >= p.strong_kl
    if row.df >= p.high_df and not sig and row.kl_smoothed_bits <= p.neutral_kl: return "frequent_class_neutral"
    if row.df >= p.high_df and strong: return "frequent_strongly_associated"
    if row.df < p.reliable_df and row.kl_raw_bits >= p.strong_kl and not sig: return "low_support_strong_looking_insufficient_evidence"
    if strong: return "associated_moderate_support"
    if sig: return "associated_weak_effect"
    return "not_significant"


# =============================== existing candidates ===============================
def audit_8gram_candidates(texts: Sequence[str], top: int = 60, min_df: int = 5, n: int = 8) -> list[tuple[str, int]]:
    """EXACT re-implementation of the existing analyze_data.duplicate_analysis boilerplate block (BOILER_N=8): dup_normalize, whitespace split
    (punctuation stays attached), fixed n-word windows (overlapping), distinct documents, top-60 with df >= 5."""
    c: collections.Counter = collections.Counter()
    for t in texts:
        w = cc.dup_normalize(t).split()
        c.update({" ".join(w[i:i + n]) for i in range(0, max(len(w) - n + 1, 0))})
    return [(k, v) for k, v in sorted(c.items(), key=lambda kv: (-kv[1], kv[0]))[:top] if v >= min_df]   # ties alphabetical (deterministic)


def audit_style_presence(texts: Sequence[str], phrases: Sequence[str], n: int = 8) -> sp.csr_matrix:
    wanted = {p: j for j, p in enumerate(phrases)}; rows, cols = [], []
    for r, t in enumerate(texts):
        w = cc.dup_normalize(t).split()
        for g in {" ".join(w[i:i + n]) for i in range(0, max(len(w) - n + 1, 0))}:
            if g in wanted: rows.append(r); cols.append(wanted[g])
    return sp.csr_matrix((np.ones(len(rows), dtype=np.float32), (rows, cols)), shape=(len(texts), len(phrases)))


def sentence_presence(texts: Sequence[str], min_df: int, min_words: int, protected: set[str]) -> tuple[sp.csr_matrix, list[str]]:
    """Document x sentence presence for whole sentences that are ELIGIBLE under the pipeline's rule definition (bh._boiler_eligible)."""
    per_doc = [{bh._sent_key(s) for s in bh._SENT.split(pp.normalize_text(t, "clinical")) if bh._boiler_eligible(s, min_words, protected)} for t in texts]
    c = collections.Counter(k for d in per_doc for k in d)
    keys = sorted(k for k, v in c.items() if v >= min_df); idx = {k: j for j, k in enumerate(keys)}
    rows, cols = [], []
    for r, d in enumerate(per_doc):
        for k in d:
            if k in idx: rows.append(r); cols.append(idx[k])
    return sp.csr_matrix((np.ones(len(rows), dtype=np.float32), (rows, cols)), shape=(len(texts), len(keys))), keys


# =============================== rule proposals (train only; NOT applied anywhere) ===============================
def propose_rules(sent_table: pd.DataFrame, train_sentence_df: dict[str, int], min_df: int, params: Params, assoc_q: float, assoc_kl: float) -> tuple[dict[str, int], pd.DataFrame]:
    """Class-neutral-only rules: an eligible sentence (df >= min_df in TRAIN) is proposed only if it is NOT significantly class-associated
    (q < assoc_q AND excess KL >= assoc_kl bits). Associated sentences are kept for investigation, not removed."""
    t = sent_table[sent_table.df >= min_df].copy()
    t["associated"] = (t.q_value_bh < assoc_q) & (t.kl_excess_bits >= assoc_kl)
    t["proposed"] = ~t.associated
    return {r.phrase: int(r.df) for r in t[t.proposed].itertuples()}, t


def compare_rule_sets(rule_sets: dict[str, dict[str, int]], texts: dict[str, Sequence[str]], min_words: int, protected: set[str], baseline: str) -> pd.DataFrame:
    """For every partition, how many documents / sentences change under each rule set (rule-driven removals + within-note repeats, i.e. the
    whole compress_text effect), and how the resulting TEXT differs from the baseline rule set. Uses text only (no labels)."""
    rows = []
    for part, ts in texts.items():
        clin = [pp.normalize_text(t, "clinical") for t in ts]
        base_out = [bh.compress_text(t, rule_sets[baseline], min_words, protected) for t in clin]
        for name, rules in rule_sets.items():
            out = [bh.compress_text(t, rules, min_words, protected) for t in clin]
            rows.append({"partition": part, "rule_set": name, "n_rules": len(rules), "documents": len(clin),
                         "documents_changed": sum(bool(r) for _, r in out), "sentences_removed_total": sum(len(r) for _, r in out),
                         "sentences_removed_by_rules": sum(k == "train_boilerplate_rule" for _, r in out for k, _ in r),
                         "sentences_removed_as_within_note_repeat": sum(k == "within_note_repeat" for _, r in out for k, _ in r),
                         f"documents_whose_text_differs_from_{baseline}": sum(a[0] != b[0] for a, b in zip(out, base_out))})
    return pd.DataFrame(rows)


# =============================== orchestration ===============================
def load_scope(args) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    df, quarantined, test, info = bh.load_and_validate(args.train, args.test, args.partial_policy)
    manifest_path = Path(args.split_manifest) if args.split_manifest else Path(args.handoff_dir) / "splits" / "split_manifest_primary_stratified.csv"
    if not manifest_path.is_file():
        raise FileNotFoundError(f"split manifest not found: {manifest_path} (pass --handoff-dir or --split-manifest)")
    m = pd.read_csv(manifest_path, dtype=str, keep_default_na=False)
    if set(m.source_record_id) != set(df.source_record_id):
        raise ValueError("split manifest does not cover exactly the cleaned training records (different data or partial policy?)")
    lab = dict(zip(m.source_record_id, m.medical_specialty))
    if any(lab[s] != l for s, l in zip(df.source_record_id, df.medical_specialty)):
        raise ValueError("labels in the split manifest differ from the cleaned records")
    df = df.merge(m[["source_record_id", "partition"]], on="source_record_id")
    return df, test, {"manifest": str(manifest_path)}


def fmt(df: pd.DataFrame) -> pd.DataFrame:
    return df.round({c: 4 for c in df.columns if df[c].dtype.kind == "f"})


def run(args) -> dict:
    params = Params(tuple(args.lengths), args.min_df, args.reliable_df, args.high_df, args.alpha, args.strong_kl, args.neutral_kl, args.smoothing,
                    args.permutations, args.seed, args.number_policy)
    out = Path(args.output_dir); out.mkdir(parents=True, exist_ok=True)
    full, test, meta = load_scope(args)
    scope_df = full[full.partition == "train"] if args.scope == "train" else full
    scope_df = scope_df.reset_index(drop=True)
    classes = list(cc.EXPECTED_LABELS)
    y = np.array([classes.index(l) for l in scope_df.medical_specialty])
    log.info("scope=%s documents=%d", args.scope, len(scope_df))
    docs = [doc_sentences(t, params.number_policy) for t in scope_df.transcription]
    X, phrases, sizes = build_phrase_matrix(docs, params.lengths, params.min_df)
    log.info("candidate phrases (df >= %d): %d", params.min_df, X.shape[1])
    assoc = compute_association(X, y, classes, params)
    assoc.insert(0, "phrase", phrases); assoc.insert(1, "n_tokens", sizes); assoc.insert(2, "phrase_source", "frequent_ngram")
    flags = pd.DataFrame([content_flags(p) for p in phrases])
    assoc = pd.concat([assoc, flags], axis=1)
    assoc["category"] = assoc.apply(lambda r: categorize(r, params), axis=1)
    # representative per document-set group: longest phrase, then alphabetical
    assoc["_rk"] = assoc.groupby("docset_group_id").apply(lambda g: g.assign(_r=g.n_tokens.rank(ascending=False, method="first"))._r).reset_index(level=0, drop=True)
    assoc["is_group_representative"] = assoc["_rk"] == 1; assoc = assoc.drop(columns="_rk")
    assoc.insert(0, "phrase_id", [f"P{i + 1:06d}" for i in range(len(assoc))])
    assoc["df_percent"] = 100.0 * assoc.df / assoc.N_documents

    # ---- existing candidates (audit 8-grams: original definition; train-rule sentences) -----------------
    protected = set(pp.DEFAULT_PROTECTED)
    audit_list = audit_8gram_candidates(full.transcription.tolist())          # exactly what analyze_data does (ALL labelled records)
    audit_match = None
    if args.audit_phrases and Path(args.audit_phrases).is_file():
        ex = pd.read_csv(args.audit_phrases, dtype=str, keep_default_na=False)
        audit_match = [tuple(r) for r in ex.itertuples(index=False, name=None)] == [(k, str(v)) for k, v in audit_list]
    Xa = audit_style_presence(scope_df.transcription.tolist(), [k for k, _ in audit_list])
    ex_rows = []
    if Xa.shape[1]:
        ea = compute_association(Xa, y, classes, params); ea.insert(0, "phrase", [k for k, _ in audit_list]); ea.insert(1, "n_tokens", 8)
        ea.insert(2, "phrase_source", "existing_audit_8gram(original tokenisation, all-labelled df in audit_df_all_labelled)")
        ea["audit_df_all_labelled"] = [v for _, v in audit_list]; ex_rows.append(ea)
    rules_path = Path(args.handoff_dir) / "datasets" / "compressed_unique_text" / "boilerplate_rules_train_only.json"
    current_rules = {}
    if rules_path.is_file():
        current_rules = json.loads(rules_path.read_text())["rules"]
    sent_table = pd.DataFrame()
    train_texts = full[full.partition == "train"].transcription.tolist()
    if args.scope == "train":
        Xs, keys = sentence_presence(scope_df.transcription.tolist(), args.rule_floor_df, args.boilerplate_min_words, protected)
        if Xs.shape[1]:
            sent_table = compute_association(Xs, y, classes, params); sent_table.insert(0, "phrase", keys); sent_table.insert(1, "n_tokens", [len(k.split()) for k in keys])
            sent_table.insert(2, "phrase_source", "sentence_candidate(eligible under the pipeline rule definition)")
            sent_table["is_current_rule"] = sent_table.phrase.isin(current_rules)
            sent_table["category"] = sent_table.apply(lambda r: categorize(r, params), axis=1)
            sent_table = pd.concat([sent_table, pd.DataFrame([content_flags(k) for k in keys])], axis=1)
            ex_rows.append(sent_table[sent_table.is_current_rule].assign(phrase_source="existing_train_rule_sentence"))
    existing = pd.concat(ex_rows, ignore_index=True) if ex_rows else pd.DataFrame()
    if len(existing):
        existing["category"] = existing.apply(lambda r: categorize(r, params), axis=1)

    # ---- outputs ---------------------------------------------------------------------------------
    P = np.bincount(y, minlength=len(classes)) / len(y)
    pd.DataFrame({"medical_specialty": classes, "documents": np.bincount(y, minlength=len(classes)), "overall_proportion": P}).round(6).to_csv(out / "class_baseline.csv", index=False)
    dist = pd.DataFrame({"phrase_id": assoc.phrase_id, "phrase": assoc.phrase, "n_tokens": assoc.n_tokens, "phrase_source": assoc.phrase_source, "df": assoc.df.astype(int), "df_percent": assoc.df_percent})
    n_cols = assoc[[f"n__{c}" for c in classes]].to_numpy(float)
    for k, c in enumerate(classes): dist[f"n__{c}"] = n_cols[:, k].astype(int)
    for k, c in enumerate(classes): dist[f"p_given_phrase__{c}"] = n_cols[:, k] / assoc.df.to_numpy()
    for k, c in enumerate(classes): dist[f"overall_p__{c}"] = P[k]
    fmt(dist).to_csv(out / "phrase_class_distribution.csv", index=False, lineterminator="\n")
    rank_cols = ["phrase_id", "phrase", "n_tokens", "phrase_source", "df", "df_percent", "category", "docset_group_id", "docset_group_size", "is_group_representative", "low_support",
                 "kl_raw_bits", "kl_smoothed_bits", "kl_null_expected_bits", "kl_excess_bits", "mi_bits", "mi_over_class_entropy", "chi2", "cramers_v", "g_stat",
                 "perm_p_value", "q_value_bh", "n_tests_bh", "permutations",
                 "top1_class", "top1_observed", "top1_expected", "top1_lift", "top1_overall_proportion", "top1_kl_share", "top1_hypergeom_p",
                 "top2_class", "top2_observed", "top2_expected", "top2_lift", "top2_overall_proportion",
                 "stopword_fraction", "contains_negation", "contains_digit", "contains_specialty_word", "section_header_like", "interpretation_hint"]
    ranking = assoc[rank_cols].copy()
    ranking["_sig"] = ranking.q_value_bh < params.alpha
    ranking = ranking.sort_values(["_sig", "kl_smoothed_bits"], ascending=[False, False]).drop(columns="_sig")
    ranking.insert(0, "association_rank", range(1, len(ranking) + 1))
    fmt(ranking).to_csv(out / "phrase_association_ranking.csv", index=False, lineterminator="\n")
    if len(existing):
        keep = [c for c in rank_cols if c in existing.columns and c not in ("phrase_id", "docset_group_id", "docset_group_size", "is_group_representative")]
        fmt(existing[keep + [c for c in ("audit_df_all_labelled", "is_current_rule") if c in existing.columns]]).to_csv(out / "existing_boilerplate_candidates.csv", index=False, lineterminator="\n")
    comparison = pd.DataFrame(); proposals: dict = {}
    if args.scope == "train" and len(sent_table):
        sent_out = sent_table.copy(); fmt(sent_out[[c for c in rank_cols if c in sent_out.columns and c not in ("phrase_id",)] + ["is_current_rule"]]).to_csv(out / "sentence_candidates_association.csv", index=False, lineterminator="\n")
        rule_sets = {"current_compressed_unique_text": current_rules or bh.fit_boilerplate([pp.normalize_text(t, "clinical") for t in train_texts], args.boilerplate_min_df, args.boilerplate_min_words, protected)}
        for tag, mdf in (("class_neutral_only_df%d" % args.boilerplate_min_df, args.boilerplate_min_df), ("class_neutral_only_df%d" % args.rule_floor_df, args.rule_floor_df)):
            rules, table = propose_rules(sent_table, {}, mdf, params, args.rule_assoc_q, args.rule_assoc_kl)
            rule_sets[tag] = rules; proposals[tag] = {"min_df_train": mdf, "n_rules": len(rules), "excluded_as_associated": int(table.associated.sum())}
        comparison = compare_rule_sets(rule_sets, {"train": train_texts, "validation": full[full.partition == "validation"].transcription.tolist(), "test": test.transcription.tolist()},
                                       args.boilerplate_min_words, protected, "current_compressed_unique_text")
        comparison.to_csv(out / "rule_comparison.csv", index=False, lineterminator="\n")
        (out / "proposed_boilerplate_rules_train_only.json").write_text(json.dumps({
            "NOT_APPLIED": "analysis proposal only; no dataset variant uses these rules", "fit_on": "train partition of the primary split (documents: %d)" % len(scope_df),
            "selection": f"eligible whole sentences with train df >= min_df, excluding sentences with q < {args.rule_assoc_q} AND excess KL >= {args.rule_assoc_kl} bits",
            "rule_sets": {k: dict(sorted(v.items(), key=lambda kv: -kv[1])) for k, v in rule_sets.items()}}, indent=2), encoding="utf-8")
    config = {"scope": args.scope, "documents": len(scope_df), "partition_counts": scope_df.partition.value_counts().to_dict(), "params": asdict(params), "manifest": meta["manifest"],
              "candidate_phrases": int(len(assoc)), "distinct_docset_tests": int(assoc.n_tests_bh.iloc[0]) if len(assoc) else 0,
              "category_counts": assoc.category.value_counts().to_dict(), "audit_replication_matches_existing_csv": audit_match, "n_existing_audit_phrases": len(audit_list),
              "current_rules": len(current_rules), "proposals": proposals,
              "labels_used": "train-partition labels only" if args.scope == "train" else "ALL labelled records incl. validation: EXPLORATORY",
              "test_set": "never used for associations; only its text is read to COUNT how many documents a rule set would change"}
    (out / "analysis_config.json").write_text(json.dumps(config, indent=2, default=str), encoding="utf-8")
    import phrase_report
    phrase_report.write_summary(out, args, params, assoc, existing, sent_table, comparison, proposals, config, classes, P, current_rules)
    return config


def parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--train", default="train.csv"); p.add_argument("--test", default="test_no_labels.csv")
    p.add_argument("--handoff-dir", default="model_handoff", help="supplies the primary split manifest and the current boilerplate rules")
    p.add_argument("--split-manifest", default=None); p.add_argument("--partial-policy", choices=["include", "quarantine"], default="include")
    p.add_argument("--output-dir", default="phrase_association")
    p.add_argument("--scope", choices=["train", "all_labeled"], default="train", help="train = primary split train partition (default); all_labeled = EXPLORATORY, no rule proposals")
    p.add_argument("--lengths", type=int, nargs="+", default=[1, 2, 3, 5, 8]); p.add_argument("--min-df", type=int, default=10)
    p.add_argument("--reliable-df", type=int, default=30); p.add_argument("--high-df", type=int, default=50)
    p.add_argument("--alpha", type=float, default=0.05); p.add_argument("--strong-kl", type=float, default=0.5); p.add_argument("--neutral-kl", type=float, default=0.10)
    p.add_argument("--smoothing", type=float, default=10.0); p.add_argument("--permutations", type=int, default=999); p.add_argument("--seed", type=int, default=42)
    p.add_argument("--number-policy", choices=["keep", "mask"], default="keep"); p.add_argument("--top-examples", type=int, default=8)
    p.add_argument("--audit-phrases", default="data_analysis/boilerplate_phrases.csv", help="existing audit file, only used to verify that the re-implementation reproduces it")
    p.add_argument("--boilerplate-min-df", type=int, default=15, help="the pipeline's current rule threshold")
    p.add_argument("--boilerplate-min-words", type=int, default=6); p.add_argument("--rule-floor-df", type=int, default=8, help="lower df used for the broader rule proposal")
    p.add_argument("--rule-assoc-q", type=float, default=0.05); p.add_argument("--rule-assoc-kl", type=float, default=0.10)
    return p.parse_args(argv)


def main(argv=None) -> int:
    args = parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", handlers=[logging.StreamHandler(sys.stdout)])
    if args.min_df < 2: raise SystemExit("--min-df must be >= 2")
    cfg = run(args)
    log.info("done: %d candidate phrases, %d distinct tests -> %s", cfg["candidate_phrases"], cfg["distinct_docset_tests"], args.output_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

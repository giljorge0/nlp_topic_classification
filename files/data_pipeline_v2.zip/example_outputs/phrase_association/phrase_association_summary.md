# Phrase-class association analysis

**Scope: TRAIN partition of the primary stratified split** (stable source IDs from the split manifest). Validation labels and the unlabeled test set are not used for any association or rule below.

Documents analysed: **2129** | candidate phrases (document frequency >= 10, lengths [1, 2, 3, 5, 8]): **24358** | distinct document-sets actually tested: **22946** | permutations: 999 | seed 42.

**High association is a reason to investigate, never by itself a reason to remove a phrase. Nothing here claims that removing or keeping any phrase changes classification quality; that needs model experiments.**

## 0. Reproduce
```
python phrase_association.py --train train.csv --test test_no_labels.csv --handoff-dir model_handoff --output-dir phrase_association --seed 42
```
Exploratory all-labelled run (no rule proposals): add `--scope all_labeled --output-dir phrase_association_exploratory`.

## 1. Audit of the existing `boilerplate_phrases.csv` method (verified from the code)
| question | answer (function / option) |
|---|---|
| producing code | `analyze_data.py`, `duplicate_analysis()`, block `# boilerplate: repeated 8-word shingles by document frequency`; length constant `BOILER_N = 8` (no CLI option) |
| input | the `usable` frame built in `main()`: every non-quarantined repaired training record (clean + recovered + recovered_partial = 2,662), from `clinical_common.ingest_train` via `records_frame` |
| text used | repaired **transcription** field only; not the preprocessed/compressed text; keywords/description/sample_name are not examined |
| partition | **all labelled records together** (no train/validation split, no test). It is a descriptive audit, not a train-only fit |
| normalisation / tokens | `clinical_common.dup_normalize` (NFKC, case-fold, whitespace collapse) then `str.split()`: whitespace tokens, **punctuation stays attached** (`fashion.` and `fashion` differ) |
| phrase length | fixed 8-word windows only; overlapping windows; **not** bounded by sentences; no other lengths |
| what counts | `documents_containing` = number of **distinct documents** (a `set` of windows per document), not occurrences |
| selection | `Counter.most_common(60)` with document frequency >= 5; labels are never used |
| downstream use | none: no code reads `boilerplate_phrases.csv` (grep). It is only written and listed in the report text |
| relation to compression rules | independent. `boilerplate_rules_train_only.json` / `compressed_unique_text` come from `build_model_handoff.fit_boilerplate` (**whole-sentence exact matches**, `_SENT` splitter, `_boiler_eligible`, TRAIN partition only, `--boilerplate-min-df 15`, `--boilerplate-min-words 6`) applied by `compress_text` |

Consequences observed: the list ranks by frequency only (no class information), and its rows are overlapping windows of the same templates (17 of the 60 listed phrases contain `draped`). Because the templates are fragments inside longer sentences, the sentence-level compression rules (currently **2** rules) cannot remove them. Re-implementation check: this module's `audit_8gram_candidates` reproduces the existing CSV exactly: **True** (None = file not supplied).

## 2. Method
* **Unit:** document presence/absence of a phrase in the transcription (never repeated occurrences). Phrases are lower-cased word n-grams inside one sentence (sentence split by the pipeline's `_SENT` on original-case text; punctuation dropped; numbers kept). Phrase lengths: [1, 2, 3, 5, 8]. Only phrases with df >= 10 are tested; rarer phrases are not interpreted.
* **Distribution:** n_pc = documents of class c containing the phrase; P(c) = overall class proportion in the analysed set; P(c|phrase) = n_pc / df.
* **KL divergence** `D_KL(P(c|phrase) || P(c))` in bits, 0*log0 = 0. `kl_raw_bits` is the plug-in value (biased upward for small df); `kl_null_expected_bits = (K-1)/(2*df*ln2)` is its expected value under independence (Miller-Madow approximation, K=12; rough when df is small or a class is rare, so rely on the permutation q-value for evidence and treat the excess as an effect-size guide); `kl_excess_bits = raw - null`. `kl_smoothed_bits` uses a Dirichlet prior pulled toward P(c) with 10 pseudo-documents: `P_s(c|phrase) = (n_pc + 10*P(c)) / (df + 10)`, so rare phrases are shrunk toward 'no association'.
* **Mutual information** `I(presence; class)` in bits from the 2 x 12 table (present/absent x class) = information gain; `mi_over_class_entropy` divides by H(class). MI weights KL by how many documents the phrase covers, so frequent phrases score higher on MI than equally concentrated rare ones.
* **Effect sizes:** KL, MI, Cramer's V (`sqrt(chi2/N)` for the 2 x K table), and for the two classes contributing most to the KL: observed vs expected documents and lift. The hypergeometric p-value of the top class is descriptive only (class chosen after looking at the data, not multiplicity-adjusted).
* **Significance:** Monte-Carlo permutation test of the G statistic (2*N*ln2*MI): class labels are shuffled across documents 999 times, p = (1 + #{G_perm >= G_obs}) / (999 + 1) (smallest possible p = 0.0010). This avoids chi-square asymptotics, which are unreliable for sparse tables with rare classes. Phrases with identical document sets (e.g. all sub-phrases of one template) are tested once; **Benjamini-Hochberg FDR** is applied across those 22946 tests (q-values reported with the p-values). `docset_group_id` links the phrases that share one test.
* **Categories** (thresholds are options): frequent = df >= 50; significant = q < 0.05; strong = significant and excess KL >= 0.5 bits; neutral = not significant and smoothed KL <= 0.1 bits; low support = df < 30.
* **Interpretation hints** are transparent heuristics (specialty/body-system word, section-header wording, share of function words), **not** clinical judgements.

## 3. Overall class distribution of the analysed documents

| medical_specialty        |   documents |   overall_proportion |
|:-------------------------|------------:|---------------------:|
| Surgery                  |         712 |               0.3344 |
| Cardiovascular-Pulmonary |         246 |               0.1155 |
| Orthopedic               |         240 |               0.1127 |
| Radiology                |         178 |               0.0836 |
| General Medicine         |         169 |               0.0794 |
| Gastroenterology         |         156 |               0.0733 |
| Neurology                |         147 |               0.069  |
| Obstetrics-Gynecology    |         108 |               0.0507 |
| Neurosurgery             |          62 |               0.0291 |
| Ophthalmology            |          58 |               0.0272 |
| Psychiatry-Psychology    |          33 |               0.0155 |
| Dermatology              |          20 |               0.0094 |

## 4. What was found

| category                                         |   phrases |
|:-------------------------------------------------|----------:|
| associated_moderate_support                      |      9382 |
| low_support_strong_looking_insufficient_evidence |      6716 |
| associated_weak_effect                           |      5005 |
| not_significant                                  |      2088 |
| frequent_strongly_associated                     |      1046 |
| frequent_class_neutral                           |       121 |

By phrase length:

|   n_tokens |   phrases |   significant_q |   strong |
|-----------:|----------:|----------------:|---------:|
|          1 |      5416 |            4011 |     2407 |
|          2 |     10712 |            6514 |     4434 |
|          3 |      6566 |            3840 |     2773 |
|          5 |      1338 |             855 |      648 |
|          8 |       326 |             213 |      166 |

### 4.1 Frequent but approximately class-neutral
Frequent in many specialties in proportion to their size (not significant after FDR, small smoothed KL). Candidates for boilerplate *if* they carry no clinical content.

| phrase        |   n_tokens |   df |   kl_smoothed_bits |   kl_raw_bits |   kl_excess_bits |   mi_bits |   q_value_bh |   lift | observed/expected (top class)   |
|:--------------|-----------:|-----:|-------------------:|--------------:|-----------------:|----------:|-------------:|-------:|:--------------------------------|
| of            |          1 | 2059 |              0     |         0     |           -0.004 |     0.003 |       0.757  |  1.02  | Neurology: 145/142.2            |
| and           |          1 | 2056 |              0     |         0     |           -0.004 |     0.007 |       0.109  |  1.008 | Surgery: 693/687.6              |
| given         |          1 |  556 |              0.016 |         0.017 |            0.003 |     0.006 |       0.133  |  1.119 | Surgery: 208/185.9              |
| prior         |          1 |  469 |              0.02  |         0.021 |            0.004 |     0.006 |       0.118  |  1.513 | Neurology: 49/32.4              |
| the patient's |          2 |  451 |              0.025 |         0.026 |            0.009 |     0.007 |       0.0545 |  1.12  | Surgery: 169/150.8              |
| of a          |          2 |  433 |              0.019 |         0.02  |            0.001 |     0.005 |       0.219  |  1.229 | Orthopedic: 60/48.8             |
| following     |          1 |  363 |              0.029 |         0.031 |            0.009 |     0.006 |       0.091  |  1.476 | Neurology: 37/25.1              |
| however       |          1 |  320 |              0.032 |         0.033 |            0.009 |     0.006 |       0.141  |  1.403 | Neurology: 31/22.1              |

### 4.2 Frequent and strongly class-associated
Split by the heuristic hint. **None of these should be removed on this evidence alone.**

**Content words present (clinical content OR note-format template: the heuristic cannot tell; a clinician must review):**

| phrase            |   n_tokens |   df |   kl_smoothed_bits |   kl_raw_bits |   kl_excess_bits |   mi_bits |   q_value_bh |   lift | observed/expected (top class)   |
|:------------------|-----------:|-----:|-------------------:|--------------:|-----------------:|----------:|-------------:|-------:|:--------------------------------|
| 2/2               |          1 |   53 |              1.603 |         2.397 |            2.247 |     0.062 |      0.00269 |  7.651 | Neurology: 28/3.7               |
| lens              |          1 |   50 |              1.624 |         2.389 |            2.23  |     0.06  |      0.00269 | 18.353 | Ophthalmology: 25/1.4           |
| right eye         |          2 |   59 |              1.639 |         2.221 |            2.086 |     0.068 |      0.00269 | 19.287 | Ophthalmology: 31/1.6           |
| memory            |          1 |   58 |              1.566 |         2.194 |            2.057 |     0.064 |      0.00269 | 17.797 | Psychiatry-Psychology: 16/0.9   |
| responses were    |          2 |   53 |              1.445 |         2.191 |            2.042 |     0.057 |      0.00269 |  7.378 | Neurology: 27/3.7               |
| plantar responses |          2 |   50 |              1.42  |         2.197 |            2.038 |     0.053 |      0.00269 |  7.241 | Neurology: 25/3.5               |
| bulk              |          1 |   53 |              1.491 |         2.182 |            2.032 |     0.057 |      0.00269 |  8.744 | Neurology: 32/3.7               |
| psychiatric       |          1 |   65 |              1.606 |         2.147 |            2.025 |     0.072 |      0.00269 | 20.843 | Psychiatry-Psychology: 21/1.0   |

**Specialty word / header or template wording / function words (artifact or leakage candidates, or simply ordinary wording; review):**

| phrase   |   n_tokens |   df |   kl_smoothed_bits |   kl_raw_bits |   kl_excess_bits |   mi_bits |   q_value_bh |   lift | interpretation_hint                                                                                       | observed/expected (top class)   |
|:---------|-----------:|-----:|-------------------:|--------------:|-----------------:|----------:|-------------:|-------:|:----------------------------------------------------------------------------------------------------------|:--------------------------------|
| y/o      |          1 |   52 |              1.585 |         2.387 |            2.234 |     0.061 |      0.00269 |  7.52  | section-header / note-template wording (incl. abbreviations like pmh, fhx): formatting-artifact candidate | Neurology: 27/3.6               |
| pmh 1    |          2 |   60 |              1.633 |         2.357 |            2.225 |     0.069 |      0.00269 |  7.241 | section-header / note-template wording (incl. abbreviations like pmh, fhx): formatting-artifact candidate | Neurology: 30/4.1               |
| coord    |          1 |   52 |              1.547 |         2.336 |            2.184 |     0.059 |      0.00269 |  7.52  | section-header / note-template wording (incl. abbreviations like pmh, fhx): formatting-artifact candidate | Neurology: 27/3.6               |
| hx this  |          2 |   63 |              1.616 |         2.305 |            2.179 |     0.071 |      0.00269 |  7.586 | section-header / note-template wording (incl. abbreviations like pmh, fhx): formatting-artifact candidate | Neurology: 33/4.3               |
| fhx      |          1 |   67 |              1.651 |         2.294 |            2.176 |     0.076 |      0.00269 |  7.35  | section-header / note-template wording (incl. abbreviations like pmh, fhx): formatting-artifact candidate | Neurology: 34/4.6               |
| shx      |          1 |   64 |              1.625 |         2.286 |            2.162 |     0.072 |      0.00269 |  7.468 | section-header / note-template wording (incl. abbreviations like pmh, fhx): formatting-artifact candidate | Neurology: 33/4.4               |
| cn       |          1 |   85 |              1.694 |         2.213 |            2.119 |     0.094 |      0.00269 |  7.327 | section-header / note-template wording (incl. abbreviations like pmh, fhx): formatting-artifact candidate | Neurology: 43/5.9               |
| hx       |          1 |   99 |              1.645 |         2.091 |            2.011 |     0.105 |      0.00269 |  7.022 | section-header / note-template wording (incl. abbreviations like pmh, fhx): formatting-artifact candidate | Neurology: 48/6.8               |

### 4.3 Lower-frequency phrases that look strongly associated but lack evidence (df < 30, not significant)
Large plug-in KL from few documents is expected by chance (see `kl_null_expected_bits`); these are **not** findings.

| phrase                |   n_tokens |   df |   kl_smoothed_bits |   kl_raw_bits |   kl_excess_bits |   mi_bits |   q_value_bh |   lift | observed/expected (top class)   |
|:----------------------|-----------:|-----:|-------------------:|--------------:|-----------------:|----------:|-------------:|-------:|:--------------------------------|
| with bipolar cautery  |          3 |   10 |              0.304 |         1.362 |            0.569 |     0.006 |       0.0518 |  3.548 | Orthopedic: 4/1.1               |
| 2.2                   |          1 |   10 |              0.282 |         1.352 |            0.558 |     0.006 |       0.0504 |  2.596 | Cardiovascular-Pulmonary: 3/1.2 |
| in its mid            |          3 |   10 |              0.293 |         1.347 |            0.553 |     0.006 |       0.0598 |  4.327 | Cardiovascular-Pulmonary: 5/1.2 |
| boy with              |          2 |   10 |              0.27  |         1.33  |            0.537 |     0.006 |       0.0504 |  2.691 | Surgery: 9/3.3                  |
| used to reapproximate |          3 |   10 |              0.273 |         1.329 |            0.536 |     0.006 |       0.0532 |  2.093 | Surgery: 7/3.3                  |
| to reapproximate the  |          3 |   10 |              0.273 |         1.329 |            0.536 |     0.006 |       0.0598 |  2.093 | Surgery: 7/3.3                  |
| coherent              |          1 |   10 |              0.342 |         1.323 |            0.529 |     0.006 |       0.0532 | 12.903 | Psychiatry-Psychology: 2/0.2    |
| end and               |          2 |   10 |              0.289 |         1.32  |            0.527 |     0.006 |       0.0558 |  5.914 | Obstetrics-Gynecology: 3/0.5    |

### 4.4 Associated phrases with moderate support (significant, strong, df below the 'frequent' cutoff)

| phrase                   |   n_tokens |   df |   kl_smoothed_bits |   kl_raw_bits |   kl_excess_bits |   mi_bits |   q_value_bh |   lift | observed/expected (top class)   |
|:-------------------------|-----------:|-----:|-------------------:|--------------:|-----------------:|----------:|-------------:|-------:|:--------------------------------|
| axis i                   |          2 |   15 |              2.261 |         5.158 |            4.629 |     0.038 |      0.00269 | 55.913 | Psychiatry-Psychology: 13/0.2   |
| married for              |          2 |   10 |              1.803 |         5.327 |            4.534 |     0.026 |      0.00269 | 58.064 | Psychiatry-Psychology: 9/0.2    |
| axis ii                  |          2 |   12 |              1.888 |         5.002 |            4.341 |     0.029 |      0.00269 | 53.763 | Psychiatry-Psychology: 10/0.2   |
| past psychiatric history |          3 |   11 |              1.746 |         4.936 |            4.214 |     0.026 |      0.00269 | 52.785 | Psychiatry-Psychology: 9/0.2    |
| axis iv                  |          2 |   11 |              1.746 |         4.936 |            4.214 |     0.026 |      0.00269 | 52.785 | Psychiatry-Psychology: 9/0.2    |
| eye contact              |          2 |   12 |              1.843 |         4.819 |            4.158 |     0.028 |      0.00269 | 53.763 | Psychiatry-Psychology: 10/0.2   |
| axis ii deferred         |          3 |   10 |              1.595 |         4.859 |            4.065 |     0.024 |      0.00269 | 51.612 | Psychiatry-Psychology: 8/0.2    |
| axis v                   |          2 |   10 |              1.595 |         4.859 |            4.065 |     0.024 |      0.00269 | 51.612 | Psychiatry-Psychology: 8/0.2    |

## 5. Existing boilerplate candidates
### 5.1 The 60 audit 8-word phrases (original definition), measured on the analysed documents
Presence uses the audit's own tokenisation (whitespace, punctuation attached, 8-word windows); association statistics as above.

| phrase                                           |   n_tokens |   df |   kl_smoothed_bits |   kl_raw_bits |   kl_excess_bits |   mi_bits |   q_value_bh |   lift | category                     | observed/expected (top class)   |
|:-------------------------------------------------|-----------:|-----:|-------------------:|--------------:|-----------------:|----------:|-------------:|-------:|:-----------------------------|:--------------------------------|
| was prepped and draped in the usual sterile      |          8 |  119 |              0.252 |         0.321 |            0.254 |     0.019 |      0.00187 |  1.608 | associated_weak_effect       | Surgery: 64/39.8                |
| the patient was taken to the operating room      |          8 |  106 |              0.357 |         0.458 |            0.383 |     0.024 |      0.00187 |  1.777 | associated_weak_effect       | Surgery: 63/35.4                |
| prepped and draped in the usual sterile fashion. |          8 |  102 |              0.288 |         0.376 |            0.298 |     0.019 |      0.00187 |  1.612 | associated_weak_effect       | Surgery: 55/34.1                |
| the patient tolerated the procedure well and was |          8 |   88 |              0.374 |         0.499 |            0.409 |     0.021 |      0.00187 |  1.767 | associated_weak_effect       | Surgery: 52/29.4                |
| the patient was brought to the operating room    |          8 |   83 |              0.309 |         0.438 |            0.343 |     0.018 |      0.00187 |  1.549 | associated_weak_effect       | Surgery: 43/27.8                |
| patient was brought to the operating room and    |          8 |   79 |              0.44  |         0.636 |            0.536 |     0.024 |      0.00187 |  1.552 | frequent_strongly_associated | Surgery: 41/26.4                |
| patient was taken to the operating room and      |          8 |   77 |              0.339 |         0.486 |            0.383 |     0.018 |      0.00187 |  1.786 | associated_weak_effect       | Surgery: 46/25.8                |
| patient was prepped and draped in the usual      |          8 |   66 |              0.563 |         0.809 |            0.688 |     0.026 |      0.00187 |  1.858 | frequent_strongly_associated | Surgery: 41/22.1                |

Category counts among the audited phrases:

| category                                         |   phrases |
|:-------------------------------------------------|----------:|
| associated_weak_effect                           |        30 |
| associated_moderate_support                      |        23 |
| frequent_strongly_associated                     |         5 |
| low_support_strong_looking_insufficient_evidence |         2 |

### 5.2 Current compression rules (train-fitted whole sentences)

| phrase                                    |   n_tokens |   df |   kl_smoothed_bits |   kl_raw_bits |   kl_excess_bits |   mi_bits |   q_value_bh |   lift | category                    | interpretation_hint                                                                                       | observed/expected (top class)   |
|:------------------------------------------|-----------:|-----:|-------------------:|--------------:|-----------------:|----------:|-------------:|-------:|:----------------------------|:----------------------------------------------------------------------------------------------------------|:--------------------------------|
| the patient tolerated the procedure well. |          6 |  147 |              0.314 |         0.383 |            0.329 |     0.028 |        0.007 |  1.546 | associated_weak_effect      | content words present: clinical content OR a note-format template - needs clinician review                | Surgery: 76/49.2                |
| the rest of the cn exam was unremarkable. |          8 |   18 |              0.997 |         2.477 |            2.036 |     0.021 |        0.007 |  8.046 | associated_moderate_support | section-header / note-template wording (incl. abbreviations like pmh, fhx): formatting-artifact candidate | Neurology: 10/1.2               |

## 6. Rule proposals vs the current `compressed_unique_text` (generated from the TRAIN partition only; NOT applied)
Proposal logic: eligible whole sentences (>= 6 words, no digit, no negation) with train df >= the stated threshold, **excluding** sentences that are significantly class-associated (q < 0.05 and excess KL >= 0.1 bits). Associated sentences are kept in the text. Evidence per sentence: `sentence_candidates_association.csv`; rules: `proposed_boilerplate_rules_train_only.json`.

| rule set                |   min_df_train |   n_rules |   excluded_as_associated |
|:------------------------|---------------:|----------:|-------------------------:|
| class_neutral_only_df15 |             15 |         0 |                        2 |
| class_neutral_only_df8  |              8 |        15 |                        9 |

Documents/sentences that would change per partition (text only; no labels read from validation or test):

| partition   | rule_set                       |   n_rules |   documents |   documents_changed |   sentences_removed_total |   sentences_removed_by_rules |   sentences_removed_as_within_note_repeat |   documents_whose_text_differs_from_current_compressed_unique_text |
|:------------|:-------------------------------|----------:|------------:|--------------------:|--------------------------:|-----------------------------:|------------------------------------------:|-------------------------------------------------------------------:|
| train       | current_compressed_unique_text |         2 |        2129 |                 294 |                       362 |                          173 |                                       189 |                                                                  0 |
| train       | class_neutral_only_df15        |         0 |        2129 |                 147 |                       197 |                            0 |                                       197 |                                                                165 |
| train       | class_neutral_only_df8         |        15 |        2129 |                 227 |                       321 |                          125 |                                       196 |                                                                247 |
| validation  | current_compressed_unique_text |         2 |         533 |                  83 |                       103 |                           51 |                                        52 |                                                                  0 |
| validation  | class_neutral_only_df15        |         0 |         533 |                  33 |                        52 |                            0 |                                        52 |                                                                 51 |
| validation  | class_neutral_only_df8         |        15 |         533 |                  49 |                        81 |                           29 |                                        52 |                                                                 67 |
| test        | current_compressed_unique_text |         2 |         398 |                  56 |                        70 |                           32 |                                        38 |                                                                  0 |
| test        | class_neutral_only_df15        |         0 |         398 |                  27 |                        39 |                            0 |                                        39 |                                                                 31 |
| test        | class_neutral_only_df8         |        15 |         398 |                  41 |                        58 |                           19 |                                        39 |                                                                 44 |

Current rules that the neutral-only logic would drop (associated):

| phrase                                    |   df |   kl_excess_bits |   q_value_bh | top1_class   |   top1_observed |   top1_expected |
|:------------------------------------------|-----:|-----------------:|-------------:|:-------------|----------------:|----------------:|
| the patient tolerated the procedure well. |  147 |            0.329 |        0.007 | Surgery      |              76 |          49.161 |
| the rest of the cn exam was unremarkable. |   18 |            2.036 |        0.007 | Neurology    |              10 |           1.243 |

No claim is made that either rule set helps or hurts classification; that would need model runs on identical splits.

## 7. How to read the output
* Rank by evidence, not by one number: `q_value_bh` (is it unlikely under independence?), `kl_excess_bits`/`kl_smoothed_bits` (how concentrated, corrected for sample size), `mi_bits` (how much information in total), `df` (support).
* **Frequent + neutral** -> plausible boilerplate. **Frequent + strongly associated** -> usually informative wording about a procedure/specialty (keep) or a template that one specialty's notes use (dataset artifact: investigate). **Low support + large raw KL** -> chance until shown otherwise.
* Associations are among **documents of this training set**; the same note appears under several specialties for 730 transcription groups (see the main analysis), which dilutes or inflates apparent concentration. Overlapping phrases are correlated; use the group representative.
* Permutation p-values cannot go below 1/(permutations+1); with many tests q-values have the same floor. Increase `--permutations` for finer resolution.
* Heuristic hints (specialty word, header wording) flag where label leakage or formatting artifacts are plausible; they do not prove it.

## 8. Files
`phrase_class_distribution.csv`, `phrase_association_ranking.csv`, `phrase_association_summary.md`, `class_baseline.csv`, `existing_boilerplate_candidates.csv`, `sentence_candidates_association.csv`, `rule_comparison.csv`, `proposed_boilerplate_rules_train_only.json`, `analysis_config.json`.

"""Writes phrase_association_summary.md (every number comes from the run; the audit section states facts verified in the code)."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd


def _t(df: pd.DataFrame) -> str:
    return df.to_markdown(index=False) if len(df) else "_none_"


def _show(df: pd.DataFrame, k: int, extra: list[str] | None = None) -> pd.DataFrame:
    cols = ["phrase", "n_tokens", "df", "kl_smoothed_bits", "kl_raw_bits", "kl_excess_bits", "mi_bits", "q_value_bh", "top1_class", "top1_observed", "top1_expected", "top1_lift"] + (extra or [])
    d = df[[c for c in cols if c in df.columns]].head(k).copy()
    d["phrase"] = d.phrase.map(lambda s: s if len(s) <= 80 else s[:77] + "...")
    d["observed/expected (top class)"] = [f"{c}: {o:.0f}/{e:.1f}" for c, o, e in zip(d.top1_class, d.top1_observed, d.top1_expected)]
    d = d.drop(columns=["top1_class", "top1_observed", "top1_expected"]).rename(columns={"top1_lift": "lift"})
    for c in ("kl_smoothed_bits", "kl_raw_bits", "kl_excess_bits", "mi_bits", "lift"):
        if c in d: d[c] = d[c].round(3)
    if "q_value_bh" in d: d["q_value_bh"] = d.q_value_bh.map(lambda x: f"{x:.3g}")
    return d


def write_summary(out: Path, args, params, assoc: pd.DataFrame, existing: pd.DataFrame, sent_table: pd.DataFrame, comparison: pd.DataFrame,
                  proposals: dict, config: dict, classes: list[str], P: np.ndarray, current_rules: dict) -> None:
    rep = assoc[assoc.is_group_representative]
    k = args.top_examples
    cats = assoc.category.value_counts().rename_axis("category").reset_index(name="phrases")
    by_len = assoc.groupby("n_tokens").agg(phrases=("phrase", "size"), significant_q=("q_value_bh", lambda s: int((s < params.alpha).sum())),
                                            strong=("category", lambda s: int(s.isin(["frequent_strongly_associated", "associated_moderate_support"]).sum()))).reset_index()
    neutral = rep[rep.category == "frequent_class_neutral"].sort_values("df", ascending=False)
    fa = rep[rep.category == "frequent_strongly_associated"].sort_values("kl_excess_bits", ascending=False)
    fa_content = fa[fa.interpretation_hint.str.startswith("content words")]
    fa_artifact = fa[~fa.interpretation_hint.str.startswith("content words")]
    low = rep[rep.category == "low_support_strong_looking_insufficient_evidence"].sort_values("kl_raw_bits", ascending=False)
    mod = rep[rep.category == "associated_moderate_support"].sort_values("kl_excess_bits", ascending=False)
    base = pd.DataFrame({"medical_specialty": classes, "documents": np.round(P * config["documents"]).astype(int), "overall_proportion": P.round(4)})
    ex_audit = existing[existing.phrase_source.str.startswith("existing_audit")] if len(existing) else pd.DataFrame()
    ex_rules = existing[existing.phrase_source == "existing_train_rule_sentence"] if len(existing) else pd.DataFrame()
    scope_note = ("**Scope: TRAIN partition of the primary stratified split** (stable source IDs from the split manifest). Validation labels and the unlabeled test set are not used for any association or rule below."
                  if args.scope == "train" else "**EXPLORATORY scope: ALL labelled records, including validation. Nothing from this run may be used to choose preprocessing rules.**")
    n_draped = int(sum("draped" in p for p in ex_audit.phrase)) if len(ex_audit) else 0
    L = []
    L.append(f"# Phrase-class association analysis\n\n{scope_note}\n\n"
             f"Documents analysed: **{config['documents']}** | candidate phrases (document frequency >= {params.min_df}, lengths {list(params.lengths)}): **{config['candidate_phrases']}** | "
             f"distinct document-sets actually tested: **{config['distinct_docset_tests']}** | permutations: {params.permutations} | seed {params.seed}.\n\n"
             "**High association is a reason to investigate, never by itself a reason to remove a phrase. Nothing here claims that removing or keeping any phrase changes classification quality; that needs model experiments.**\n")
    L.append("## 0. Reproduce\n```\npython phrase_association.py --train train.csv --test test_no_labels.csv --handoff-dir model_handoff --output-dir phrase_association --seed 42\n```\n"
             "Exploratory all-labelled run (no rule proposals): add `--scope all_labeled --output-dir phrase_association_exploratory`.\n")
    L.append("## 1. Audit of the existing `boilerplate_phrases.csv` method (verified from the code)\n"
             "| question | answer (function / option) |\n|---|---|\n"
             "| producing code | `analyze_data.py`, `duplicate_analysis()`, block `# boilerplate: repeated 8-word shingles by document frequency`; length constant `BOILER_N = 8` (no CLI option) |\n"
             "| input | the `usable` frame built in `main()`: every non-quarantined repaired training record (clean + recovered + recovered_partial = 2,662), from `clinical_common.ingest_train` via `records_frame` |\n"
             "| text used | repaired **transcription** field only; not the preprocessed/compressed text; keywords/description/sample_name are not examined |\n"
             "| partition | **all labelled records together** (no train/validation split, no test). It is a descriptive audit, not a train-only fit |\n"
             "| normalisation / tokens | `clinical_common.dup_normalize` (NFKC, case-fold, whitespace collapse) then `str.split()`: whitespace tokens, **punctuation stays attached** (`fashion.` and `fashion` differ) |\n"
             "| phrase length | fixed 8-word windows only; overlapping windows; **not** bounded by sentences; no other lengths |\n"
             "| what counts | `documents_containing` = number of **distinct documents** (a `set` of windows per document), not occurrences |\n"
             "| selection | `Counter.most_common(60)` with document frequency >= 5; labels are never used |\n"
             "| downstream use | none: no code reads `boilerplate_phrases.csv` (grep). It is only written and listed in the report text |\n"
             "| relation to compression rules | independent. `boilerplate_rules_train_only.json` / `compressed_unique_text` come from `build_model_handoff.fit_boilerplate` (**whole-sentence exact matches**, `_SENT` splitter, `_boiler_eligible`, TRAIN partition only, `--boilerplate-min-df 15`, `--boilerplate-min-words 6`) applied by `compress_text` |\n\n"
             f"Consequences observed: the list ranks by frequency only (no class information), and its rows are overlapping windows of the same templates ({n_draped} of the {len(ex_audit)} listed phrases contain `draped`). "
             f"Because the templates are fragments inside longer sentences, the sentence-level compression rules (currently **{len(current_rules)}** rules) cannot remove them. "
             f"Re-implementation check: this module's `audit_8gram_candidates` reproduces the existing CSV exactly: **{config['audit_replication_matches_existing_csv']}** (None = file not supplied).\n")
    L.append("## 2. Method\n"
             "* **Unit:** document presence/absence of a phrase in the transcription (never repeated occurrences). Phrases are lower-cased word n-grams inside one sentence (sentence split by the pipeline's `_SENT` on original-case text; punctuation dropped; numbers "
             f"{'kept' if params.number_policy == 'keep' else 'masked as <num>'}). Phrase lengths: {list(params.lengths)}. Only phrases with df >= {params.min_df} are tested; rarer phrases are not interpreted.\n"
             "* **Distribution:** n_pc = documents of class c containing the phrase; P(c) = overall class proportion in the analysed set; P(c|phrase) = n_pc / df.\n"
             "* **KL divergence** `D_KL(P(c|phrase) || P(c))` in bits, 0*log0 = 0. `kl_raw_bits` is the plug-in value (biased upward for small df); `kl_null_expected_bits = (K-1)/(2*df*ln2)` is its expected value under independence (Miller-Madow approximation, K=12; rough when df is small or a class is rare, so rely on the permutation q-value for evidence and treat the excess as an effect-size guide); `kl_excess_bits = raw - null`. "
             f"`kl_smoothed_bits` uses a Dirichlet prior pulled toward P(c) with {params.smoothing:g} pseudo-documents: `P_s(c|phrase) = (n_pc + {params.smoothing:g}*P(c)) / (df + {params.smoothing:g})`, so rare phrases are shrunk toward 'no association'.\n"
             "* **Mutual information** `I(presence; class)` in bits from the 2 x 12 table (present/absent x class) = information gain; `mi_over_class_entropy` divides by H(class). MI weights KL by how many documents the phrase covers, so frequent phrases score higher on MI than equally concentrated rare ones.\n"
             "* **Effect sizes:** KL, MI, Cramer's V (`sqrt(chi2/N)` for the 2 x K table), and for the two classes contributing most to the KL: observed vs expected documents and lift. The hypergeometric p-value of the top class is descriptive only (class chosen after looking at the data, not multiplicity-adjusted).\n"
             f"* **Significance:** Monte-Carlo permutation test of the G statistic (2*N*ln2*MI): class labels are shuffled across documents {params.permutations} times, p = (1 + #{{G_perm >= G_obs}}) / ({params.permutations} + 1) (smallest possible p = {1 / (params.permutations + 1):.4f}). This avoids chi-square asymptotics, which are unreliable for sparse tables with rare classes. "
             f"Phrases with identical document sets (e.g. all sub-phrases of one template) are tested once; **Benjamini-Hochberg FDR** is applied across those {config['distinct_docset_tests']} tests (q-values reported with the p-values). `docset_group_id` links the phrases that share one test.\n"
             f"* **Categories** (thresholds are options): frequent = df >= {params.high_df}; significant = q < {params.alpha}; strong = significant and excess KL >= {params.strong_kl} bits; neutral = not significant and smoothed KL <= {params.neutral_kl} bits; low support = df < {params.reliable_df}.\n"
             "* **Interpretation hints** are transparent heuristics (specialty/body-system word, section-header wording, share of function words), **not** clinical judgements.\n")
    L.append(f"## 3. Overall class distribution of the analysed documents\n\n{_t(base)}\n")
    L.append(f"## 4. What was found\n\n{_t(cats)}\n\nBy phrase length:\n\n{_t(by_len)}\n")
    L.append("### 4.1 Frequent but approximately class-neutral\nFrequent in many specialties in proportion to their size (not significant after FDR, small smoothed KL). Candidates for boilerplate *if* they carry no clinical content.\n\n" + _t(_show(neutral, k)) + "\n")
    L.append("### 4.2 Frequent and strongly class-associated\nSplit by the heuristic hint. **None of these should be removed on this evidence alone.**\n\n"
             "**Content words present (clinical content OR note-format template: the heuristic cannot tell; a clinician must review):**\n\n" + _t(_show(fa_content, k)) + "\n\n"
             "**Specialty word / header or template wording / function words (artifact or leakage candidates, or simply ordinary wording; review):**\n\n" + _t(_show(fa_artifact, k, ["interpretation_hint"])) + "\n")
    L.append(f"### 4.3 Lower-frequency phrases that look strongly associated but lack evidence (df < {params.reliable_df}, not significant)\nLarge plug-in KL from few documents is expected by chance (see `kl_null_expected_bits`); these are **not** findings.\n\n" + _t(_show(low, k)) + "\n")
    L.append("### 4.4 Associated phrases with moderate support (significant, strong, df below the 'frequent' cutoff)\n\n" + _t(_show(mod, k)) + "\n")
    L.append("## 5. Existing boilerplate candidates\n### 5.1 The 60 audit 8-word phrases (original definition), measured on the analysed documents\n"
             "Presence uses the audit's own tokenisation (whitespace, punctuation attached, 8-word windows); association statistics as above.\n\n" +
             (_t(_show(ex_audit.sort_values("df", ascending=False), k, ["category"]).assign(**{})) if len(ex_audit) else "_not computed_") +
             ("\n\nCategory counts among the audited phrases:\n\n" + _t(ex_audit.category.value_counts().rename_axis("category").reset_index(name="phrases")) if len(ex_audit) else "") + "\n")
    L.append("### 5.2 Current compression rules (train-fitted whole sentences)\n\n" + (_t(_show(ex_rules, 10, ["category", "interpretation_hint"])) if len(ex_rules) else "_no rule sentence reached the analysis threshold, or the rules file was not found_") + "\n")
    if args.scope == "train" and len(comparison):
        pr = pd.DataFrame([{"rule set": k_, **v} for k_, v in proposals.items()])
        L.append("## 6. Rule proposals vs the current `compressed_unique_text` (generated from the TRAIN partition only; NOT applied)\n"
                 f"Proposal logic: eligible whole sentences (>= {args.boilerplate_min_words} words, no digit, no negation) with train df >= the stated threshold, **excluding** sentences that are significantly class-associated (q < {args.rule_assoc_q} and excess KL >= {args.rule_assoc_kl} bits). "
                 "Associated sentences are kept in the text. Evidence per sentence: `sentence_candidates_association.csv`; rules: `proposed_boilerplate_rules_train_only.json`.\n\n" + _t(pr) + "\n\n"
                 "Documents/sentences that would change per partition (text only; no labels read from validation or test):\n\n" + _t(comparison) + "\n\n"
                 "Current rules that the neutral-only logic would drop (associated):\n\n" + _t(sent_table[sent_table.is_current_rule & ((sent_table.q_value_bh < args.rule_assoc_q) & (sent_table.kl_excess_bits >= args.rule_assoc_kl))][["phrase", "df", "kl_excess_bits", "q_value_bh", "top1_class", "top1_observed", "top1_expected"]].round(3)) + "\n\n"
                 "No claim is made that either rule set helps or hurts classification; that would need model runs on identical splits.\n")
    L.append("## 7. How to read the output\n"
             "* Rank by evidence, not by one number: `q_value_bh` (is it unlikely under independence?), `kl_excess_bits`/`kl_smoothed_bits` (how concentrated, corrected for sample size), `mi_bits` (how much information in total), `df` (support).\n"
             "* **Frequent + neutral** -> plausible boilerplate. **Frequent + strongly associated** -> usually informative wording about a procedure/specialty (keep) or a template that one specialty's notes use (dataset artifact: investigate). **Low support + large raw KL** -> chance until shown otherwise.\n"
             "* Associations are among **documents of this training set**; the same note appears under several specialties for 730 transcription groups (see the main analysis), which dilutes or inflates apparent concentration. Overlapping phrases are correlated; use the group representative.\n"
             "* Permutation p-values cannot go below 1/(permutations+1); with many tests q-values have the same floor. Increase `--permutations` for finer resolution.\n"
             "* Heuristic hints (specialty word, header wording) flag where label leakage or formatting artifacts are plausible; they do not prove it.\n")
    L.append("## 8. Files\n`phrase_class_distribution.csv`, `phrase_association_ranking.csv`, `phrase_association_summary.md`, `class_baseline.csv`, `existing_boilerplate_candidates.csv`, "
             + ("`sentence_candidates_association.csv`, `rule_comparison.csv`, `proposed_boilerplate_rules_train_only.json`, " if args.scope == "train" else "") + "`analysis_config.json`.\n")
    (out / "phrase_association_summary.md").write_text("\n".join(L), encoding="utf-8")
